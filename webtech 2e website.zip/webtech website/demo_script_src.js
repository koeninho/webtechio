$(document).ready(function(){
	
	//Customization menu
	
	$("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
	$("#default").click(function(){
		$("p").css({"font-weight": "bold", "font-size": "medium", "font-style": "normal", "color": "black" });
	});
	$("#bold").click(function(){
		$("p").css("font-size", "large");
	});
	$("#italic").click(function(){
		$("p").css("font-style", "italic");
	});
	$("#red").click(function(){
		$("p").css("color", "red");
	});
	$("#green").click(function(){
		$("p").css("color", "green");
	});
	$("#blue").click(function(){
		$("p").css("color", "blue");
	});
	
});

//websitepagina.html
function showGame() {
    document.getElementById('cod4Game').style.display = "inline";
} 

//studios.html
function showLogo() {
    document.getElementById('inflogo').style.display = "inline";
} 

function showLogo2() {
    document.getElementById('shlogo').style.display = "inline";
} 

function showLogo3() {
    document.getElementById('talogo').style.display = "inline";
} 

//==========================knowledgebase.html==========================
var publisher = class {
  constructor(name) {
    this.name = name;
  }
};

class developer extends publisher{
  constructor (name, host) {
    super(name);
    this.host = host;
  }
  talk() {
    alert("Studio " + this.name + " produced " + this.host + "!");
  }
}
iwinfo = new developer("Infinity ward", "the Modern Warfare series, Ghosts and Infinite Warfare");

$(document).ready(function(){
	$("#iwdesc").click(function(){
		$("#iwtext").slideToggle("slow", function(){
			iwinfo.talk()
		});			
	});
});

shinfo = new developer("Sledgehammer", "Advanced Warfare");

$(document).ready(function(){
	$("#shdesc").click(function(){
		$("#shtext").slideToggle("slow", function(){
			shinfo.talk()
		});			
	});
});

tainfo = new developer("Treyarch", "World at War, the Black Ops series");

$(document).ready(function(){
	$("#tadesc").click(function(){
		$("#tatext").slideToggle("slow", function(){
			tainfo.talk()
		});	
	});
});

$( function() {
    $( "#tabs" ).tabs();
  } );
  
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017"],
        datasets: [{
            label: 'total revenue in billions',
            data: [4.4, 4.8, 4.9, 4.6, 4.4, 4.7, 6.6, 7],
				  
            backgroundColor: [ 
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        },
		 {
			label: 'Call Of Duty revenue',
            data: [1.8, 1.82 , 1.75, 1.6, 1.2, 1.56, 0.72, 0.70],
				  
            backgroundColor: [ 
                'rgba(140, 88, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
			
		}]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
				