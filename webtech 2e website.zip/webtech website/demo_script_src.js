$(document).ready(function(){
	
	//Customization menu
	
	$("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
	$("#default").click(function(){
		$("p").css({"font-weight": "bold", "font-size": "medium", "font-style": "normal", "color": "black" });
	});
	$("#bold").click(function(){
		$("p").css("font-size", "large");
	});
	$("#italic").click(function(){
		$("p").css("font-style", "italic");
	});
	$("#red").click(function(){
		$("p").css("color", "red");
	});
	$("#green").click(function(){
		$("p").css("color", "green");
	});
	$("#blue").click(function(){
		$("p").css("color", "blue");
	});
});

//websitepagina.html
function showGame() {
    document.getElementById('cod4Game').style.display = "inline";
} 

//studios.html
function showLogo() {
    document.getElementById('inflogo').style.display = "inline";
} 

function showLogo2() {
    document.getElementById('shlogo').style.display = "inline";
} 

function showLogo3() {
    document.getElementById('talogo').style.display = "inline";
} 

//knowledgebase.html
var publisher = class {
  constructor(name) {
    this.name = name;
  }
  talk() {
    alert("Meow, I am "+this.name+"!");
  }
};

class developer extends publisher{
  constructor (name, host) {
    super(name);
    this.host = host;
  }
  talk() {
    alert("Meow, I am " + this.name + "! My host is " + this.host + "!");
  }
}
iwinfo = new developer("infinity ward", "niggers69");

$(document).ready(function(){
	$("#iwdesc").click(function(){
		$("#iwtext").slideToggle("slow", function(){
			iwinfo.talk()
		});			
	});
});

shinfo = new developer("sledgehammer", "nigger420");

$(document).ready(function(){
	$("#shdesc").click(function(){
		$("#shtext").slideToggle("slow", function(){
			shinfo.talk()
		});			
	});
});

tainfo = new developer("treyarch", "fk me");

$(document).ready(function(){
	$("#tadesc").click(function(){
		$("#tatext").slideToggle("slow", function(){
			tainfo.talk()
		});	
	});
});
