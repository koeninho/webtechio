//==========================	JQuery	=========================

$(document).ready(function(){
	
	//Customization menu
	
	$("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
	$("#default").click(function(){
		$("p").css({"font-weight": "bold", "font-size": "medium", "font-style": "normal", "color": "black" });
	});
	$("#bold").click(function(){
		$("p").css("font-size", "large");
	});
	$("#italic").click(function(){
		$("p").css("font-style", "italic");
	});
	$("#red").click(function(){
		$("p").css("color", "red");
	});
	$("#green").click(function(){
		$("p").css("color", "green");
	});
	$("#blue").click(function(){
		$("p").css("color", "blue");
	});
});

//=========================	Javascript	=========================

//websitepagina.html
function showGame() {
    document.getElementById('cod4Game').style.display = "inline";
} 

//mw2.html

//studios.html
function showLogo() {
    document.getElementById('inflogo').style.display = "inline";
} 

function showLogo2() {
    document.getElementById('shlogo').style.display = "inline";
} 

function showLogo3() {
    document.getElementById('talogo').style.display = "inline";
} 