$(document).ready(function(){
	
	//Customization menu
	
	$("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
	$("#default").click(function(){
		$("p").css({"font-weight": "bold", "font-size": "medium", "font-style": "normal", "color": "black" });
	});
	$("#bold").click(function(){
		$("p").css("font-size", "large");
	});
	$("#italic").click(function(){
		$("p").css("font-style", "italic");
	});
	$("#red").click(function(){
		$("p").css("color", "red");
	});
	$("#green").click(function(){
		$("p").css("color", "green");
	});
	$("#blue").click(function(){
		$("p").css("color", "blue");
	});
	
});

//websitepagina.html
function showGame() {
    document.getElementById('cod4Game').style.display = "inline";
} 

//studios.html
function showLogo() {
    document.getElementById('inflogo').style.display = "inline";
} 

function showLogo2() {
    document.getElementById('shlogo').style.display = "inline";
} 

function showLogo3() {
    document.getElementById('talogo').style.display = "inline";
} 

//==========================knowledgebase.html==========================
var publisher = class {
  constructor(name) {
    this.name = name;
  }
};

class developer extends publisher{
  constructor (name, host) {
    super(name);
    this.host = host;
  }
  talk() {
    alert("Studio " + this.name + " produced " + this.host + "!");
  }
}
iwinfo = new developer("Infinity ward", "the Modern Warfare series, Ghosts and Infinite Warfare");

$(document).ready(function(){
	$("#iwdesc").click(function(){
		$("#iwtext").slideToggle("slow", function(){
			iwinfo.talk()
		});			
	});
});

shinfo = new developer("Sledgehammer", "Advanced Warfare");

$(document).ready(function(){
	$("#shdesc").click(function(){
		$("#shtext").slideToggle("slow", function(){
			shinfo.talk()
		});			
	});
});

tainfo = new developer("Treyarch", "World at War, the Black Ops series");

$(document).ready(function(){
	$("#tadesc").click(function(){
		$("#tatext").slideToggle("slow", function(){
			tainfo.talk()
		});	
	});
});

$( function() {
    $( "#tabs" ).tabs();
  } );
  
  	TESTER = document.getElementById('tester');
				Plotly.plot( TESTER, [{
				x: [1, 2, 3, 4, 5],
				y: [1, 2, 4, 8, 16] }], {
				margin: { t: 0 } } );

				