$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
}); 

$(document).ready(function(){
	$("#default").click(function(){
		$("p").css({"font-weight": "bold", "font-size": "medium", "font-style": "normal", "color": "black" });
	});
	$("#bold").click(function(){
		$("p").css("font-size", "large");
	});
	$("#italic").click(function(){
		$("p").css("font-style", "italic");
	});
	$("#red").click(function(){
		$("p").css("color", "red");
	});
	$("#green").click(function(){
		$("p").css("color", "green");
	});
	$("#blue").click(function(){
		$("p").css("color", "blue");
	});
});
