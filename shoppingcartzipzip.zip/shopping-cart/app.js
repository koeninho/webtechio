var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var expressHbs = require('express-handlebars');
var fs = require("fs");
var file = __dirname + "/" + "test.db";
var exists = fs.existsSync(file);
if(!exists) {
fs.openSync(file, "w");
}
var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database(file);
db.serialize(function() {
if(!exists) {
db.run("CREATE TABLE users (name TEXT, password TEXT)");
}
var stmt = db.prepare("INSERT INTO users VALUES (?, ?)");

stmt.run("Name #", "homobiel" );
stmt.run("adolf", "gas" );


db.each("SELECT rowid AS id, name FROM users", function(err, row) {
console.log(row.id + ": " + row.name);
});


db.run("CREATE TABLE products (pid TEXT)");

var stmt2 = db.prepare("INSERT INTO products VALUES (?)");
var rnd2;
for (var i = 0; i < 10; i++) {
rnd2 = Math.floor(Math.random() * 10000000);
stmt2.run("pid #" + rnd2);
}
stmt2.finalize();
stmt.finalize();
db.each("SELECT rowid AS id, pid FROM products", function(err, row) {
console.log(row.id + ": " + row.pid);
});
});
db.close();

var indexRouter = require('./routes/index');

var app = express();

// view engine setup
app.engine('.hbs', expressHbs({defaultLayout: 'layout', extname: '.hbs'}));
app.set('view engine', '.hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
